package com.example.comic_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
