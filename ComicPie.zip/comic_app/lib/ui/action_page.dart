import 'package:comic_app/ui/bleach_detailed.dart';
import 'package:comic_app/ui/favorite_button.dart';
import 'package:flutter/material.dart';

class ActionPage extends StatelessWidget {
  const ActionPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 218, 102, 67),
        title: Text(
          'Action',
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: SingleChildScrollView(
        child: SafeArea(
          child: Column(
            children: <Widget>[
              SizedBox(
                height: 25,
              ),

              /// Container daftar komik
              Container(
                height: 600,
                color: Colors.white,
                child: Column(
                  children: <Widget>[
                    GridView.count(
                      scrollDirection: Axis.vertical,
                      shrinkWrap: true,
                      primary: false,
                      crossAxisCount: 3,
                      childAspectRatio: (1 / 2.5),
                      children: <Widget>[
                        Container(
                          child: Column(
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(
                                    left: 10, top: 10, bottom: 10),
                                child: InkWell(
                                  onTap: () {
                                    Navigator.push(context,
                                        MaterialPageRoute(builder: (context) {
                                      return BleachDetailed();
                                    }));
                                  },
                                  child: Image.asset(
                                    'images/Bleach-volume-73.jpg',
                                    //scale: 1.7,
                                  ),
                                ),
                              ),
                              Text(
                                'Bleach',
                                style: TextStyle(
                                  color: Colors.black,
                                ),
                              ),
                              /*Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    primary: Color.fromARGB(255, 218, 102, 67),
                                  ),
                                  child: Text('Favorit'),
                                  onPressed: () {},
                                ),
                              ),*/
                              FavoriteButton(),
                            ],
                          ),
                        ),
                        Container(
                          child: Column(
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(
                                    left: 10, top: 10, bottom: 10),
                                child: Image.asset(
                                  'images/naruto_volume 63.jpg',
                                  scale: 7.1,
                                ),
                              ),
                              Text(
                                'Naruto',
                                style: TextStyle(
                                  color: Colors.black,
                                ),
                              ),
                              /*Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    primary: Color.fromARGB(255, 218, 102, 67),
                                  ),
                                  child: Text('Favorit'),
                                  onPressed: () {},
                                ),
                              ),*/
                              FavoriteButton(),
                            ],
                          ),
                        ),
                        Container(
                          child: Column(
                            children: [
                              Padding(
                                padding:
                                    const EdgeInsets.only(top: 10, bottom: 10),
                                child: Image.asset(
                                  'images/dragon-ball-super_volume 14.webp',
                                  scale: 9.7,
                                ),
                              ),
                              Text(
                                'Dragon Ball \nSuper',
                                style: TextStyle(color: Colors.black),
                              ),
                              /*Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    primary: Color.fromARGB(255, 218, 102, 67),
                                  ),
                                  child: Text('Favorit'),
                                  onPressed: () {},
                                ),
                              ),*/
                              FavoriteButton(),
                            ],
                          ),
                        ),
                        Container(
                          child: Column(
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(
                                    left: 10, top: 10, bottom: 10),
                                child: Image.asset(
                                  'images/HxH_Volume 10.jpg',
                                  scale: 7,
                                ),
                              ),
                              Text(
                                'Hunter X \nHunter',
                                style: TextStyle(color: Colors.black),
                              ),
                              /*Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    primary: Color.fromARGB(255, 218, 102, 67),
                                  ),
                                  child: Text('Favorit'),
                                  onPressed: () {},
                                ),
                              ),*/
                              FavoriteButton(),
                            ],
                          ),
                        ),
                        Container(
                          child: Column(
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(
                                    left: 1, top: 10, bottom: 10),
                                child: Image.asset(
                                  'images/one punch man_volume 25.jpg',
                                  scale: 7.3,
                                ),
                              ),
                              Text(
                                'One Punch \nMan',
                                style: TextStyle(
                                  color: Colors.black,
                                ),
                              ),
                              /*Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    primary: Color.fromARGB(255, 218, 102, 67),
                                  ),
                                  child: Text('Favorit'),
                                  onPressed: () {},
                                ),
                              ),*/
                              FavoriteButton(),
                            ],
                          ),
                        ),
                        Container(
                          child: Column(
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(
                                    top: 10, bottom: 10, right: 10),
                                child: Image.asset(
                                  'images/My Hero Academia_volume 4.jpg',
                                  scale: 6.1,
                                ),
                              ),
                              Text(
                                'My Hero \nAcademia',
                                style: TextStyle(
                                  color: Colors.black,
                                ),
                              ),
                              /*Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    primary: Color.fromARGB(255, 218, 102, 67),
                                  ),
                                  child: Text('Favorit'),
                                  onPressed: () {},
                                ),
                              ),*/
                              FavoriteButton(),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 25,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
