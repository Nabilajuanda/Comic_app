import 'package:comic_app/ui/bleach_detailed.dart';
import 'package:flutter/material.dart';

class ActionPage extends StatelessWidget {
  const ActionPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 255, 121, 80),
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 218, 102, 67),
        title: Text(
          'Action',
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: SingleChildScrollView(
        child: SafeArea(
          child: Column(
            children: <Widget>[
              SizedBox(
                height: 25,
              ),

              /// Container daftar komik
              Container(
                height: 500,
                color: Color.fromARGB(255, 156, 73, 48),
                child: Column(
                  children: <Widget>[
                    /// Row 1
                    Row(
                      children: <Widget>[
                        Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.all(10),
                              child: InkWell(
                                onTap: () {
                                  Navigator.push(context,
                                      MaterialPageRoute(builder: (context) {
                                    return BleachDetailed();
                                  }));
                                },
                                child: Image.asset(
                                  'images/Bleach-volume-73.jpg',
                                  scale: 1.7,
                                ),
                              ),
                            ),
                            Text(
                              'Bleach',
                              style: TextStyle(
                                color: Colors.white,
                              ),
                            )
                          ],
                        ),
                        Column(
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.only(
                                  top: 10, bottom: 10, right: 10),
                              child: Image.asset(
                                'images/naruto_volume 63.jpg',
                                scale: 7.1,
                              ),
                            ),
                            Text(
                              'Naruto',
                              style: TextStyle(
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                        Column(
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.only(
                                  top: 10, bottom: 10, right: 10),
                              child: Image.asset(
                                'images/dragon-ball-super_volume 14.webp',
                                scale: 9.7,
                              ),
                            ),
                            Text(
                              'Dragon Ball \nSuper',
                              style: TextStyle(color: Colors.white),
                            ),
                          ],
                        ),
                      ],
                    ),

                    /// Row 2
                    Row(
                      children: <Widget>[
                        Column(
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.all(10),
                              child: Image.asset(
                                'images/HxH_Volume 10.jpg',
                                scale: 7,
                              ),
                            ),
                            Text(
                              'Hunter X Hunter',
                              style: TextStyle(color: Colors.white),
                            ),
                          ],
                        ),
                        Column(
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.only(
                                  right: 10, top: 10, bottom: 10),
                              child: Image.asset(
                                'images/one punch man_volume 25.jpg',
                                scale: 7.3,
                              ),
                            ),
                            Text(
                              'One Punch Man',
                              style: TextStyle(
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                        Column(
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.only(
                                  top: 10, bottom: 10, right: 10),
                              child: Image.asset(
                                'images/My Hero Academia_volume 4.jpg',
                                scale: 6.4,
                              ),
                            ),
                            Text(
                              'My Hero \nAcademia',
                              style: TextStyle(
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
