import 'package:flutter/material.dart';

class BleachDetailed extends StatelessWidget {
  const BleachDetailed({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 255, 121, 80),
      body: SingleChildScrollView(
        child: SafeArea(
          child: Column(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.only(top: 10.0, bottom: 25.0),
                child: Container(
                  color: Color.fromARGB(255, 218, 102, 67),
                  padding: const EdgeInsets.only(
                      top: 5, bottom: 5, left: 140, right: 140),
                  child: Text(
                    'Bleach',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 25,
                      fontFamily: 'OpenSans-Medium',
                    ),
                  ),
                ),
              ),

              /// List Gambar Atas
              Container(
                padding: const EdgeInsets.all(15.0),
                color: Color.fromARGB(255, 156, 73, 48),
                height: 250,
                child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.only(left: 10.0, right: 10.0),
                        child: Image.asset('images/Bleach-volume-70.jpg'),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 10.0, right: 10.0),
                        child: Image.asset('images/Bleach-volume-72.jpg'),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 10.0, right: 10.0),
                        child: Image.asset('images/Bleach-volume-73.jpg'),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 10.0, right: 10.0),
                        child: Image.asset('images/Bleach-volume-74.jpg'),
                      ),
                    ]),
              ),

              const Divider(
                height: 80,
                thickness: 2.5,
                color: Color.fromARGB(255, 218, 102, 67),
              ),

              /// Container Sinopsis Komik
              Container(
                decoration: BoxDecoration(
                  color: Color.fromARGB(255, 218, 67, 67),
                  borderRadius: BorderRadius.all(
                    Radius.circular(15),
                  ),
                ),
                margin: const EdgeInsets.only(
                    left: 10.0, bottom: 20.0, right: 10.0),
                padding: const EdgeInsets.all(15.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    Text(
                      style: TextStyle(
                        color: Colors.white,
                      ),
                      'Author \t\t\t\tTite Kubo \nPenerbit \t\t\tShueisha \nTerbit \t\t\t\t\t20 Agustus 2001 - 22 Agustus 2016',
                    ),
                    Text(
                      style: TextStyle(color: Colors.white),
                      textAlign: TextAlign.justify,
                      '\n\nSinopsis \n\nIchigo Kurosaki adalah seorang remaja dari Kota Karakura yang dapat melihat hantu, kemampuan yang nanti akan membawanya bertemu dengan sosok supernatural bernama Rukia Kuchiki. Rukia adalah seorang Shinigami, yang dipercaya untuk menuntun jiwa-jiwa orang mati dari Dunia Nyata ke Soul Society (Dunia Roh Mati)—sebuah alam baka spiritual yang merupakan tempat asalnya—dan juga untuk membasmi Hollow, jiwa tersesat mirip monster yang dapat menyerang arwah dan manusia. \n\nKetika Rukia terluka parah saat melindungi Ichigo dari Hollow yang dikejarnya, Rukia memberikan kekuatannya kepada Ichigo agar dia dapat menggantikannya sementara Rukia memulihkan diri. Rukia kemudian terperangkap dalam tubuh manusia biasa, dan menasihati Ichigo yang mencoba untuk menyeimbangkan tugasnya sebagai Shinigami pengganti sambil tetap masuk sekolah. \n\nKemudian, Rukia ditangkap oleh para Shinigami atasannya dan dijatuhi hukuman mati karena telah melakukan tindakan terlarang berupa pemberian kekuatan kepada manusia. Ichigo dan kawan-kawannya berangkat dengan bantuan dari ilmuwan sekaligus mantan Shinigami bernama Kisuke Urahara, yang juga membuat Ichigo dapat menggunakan kekuatan Shinigaminya, untuk memasuki Soul Society dan menyelamatkan Rukia. \n\nNamun konflik besar terjadi diantara para kapten Soul Society, secara tidak langsung melibatkan Ichigo di dalamnya.',
                    ),
                  ],
                ),
              ),

              /// Container Tombol Kembali
              Container(
                padding: const EdgeInsets.only(bottom: 15.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    CircleAvatar(
                      backgroundColor: Color.fromARGB(255, 218, 102, 67),
                      child: IconButton(
                        icon: const Icon(
                          Icons.arrow_back,
                        ),
                        onPressed: () {
                          Navigator.pop(context);
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
