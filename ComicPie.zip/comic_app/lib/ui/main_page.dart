import 'package:comic_app/ui/action_page.dart';
import 'package:comic_app/ui/bleach_detailed.dart';
import 'package:flutter/material.dart';

class MainPage extends StatelessWidget {
  const MainPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 255, 121, 80),
      body: SingleChildScrollView(
        child: SafeArea(
          child: Column(
            children: <Widget>[
              /// Container ket. update terbaru
              Container(
                alignment: Alignment.topLeft,
                padding: const EdgeInsets.only(
                    right: 10.0, left: 10.0, bottom: 10.0, top: 30.0),
                child: Text(
                  'Update Terbaru',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontFamily: 'OpenSans-Medium',
                  ),
                ),
              ),

              /// Container komik new update
              Container(
                color: Color.fromARGB(255, 218, 102, 67),
                padding: const EdgeInsets.all(8),
                height: 270,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.only(left: 10.0, right: 10.0),
                      child: Image.asset('images/Jujutsu Kaisen_Volume 1.webp'),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 10.0, right: 10.0),
                      child: Image.asset('images/Vinland Saga_volume 01.jpg'),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 10.0, right: 10.0),
                      child: Image.asset('images/HxH_Volume 10.jpg'),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 10.0, right: 10.0),
                      child: Image.asset('images/One Piece_Volume 1.webp'),
                    ),
                  ],
                ),
              ),

              /// Container ket. baru dibaca
              Container(
                alignment: Alignment.topLeft,
                padding: const EdgeInsets.only(
                    bottom: 5.0, left: 10.0, right: 10.0, top: 35.0),
                child: Text(
                  'Baru Dibaca',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                  ),
                ),
              ),

              /// container komik baru dibaca
              Container(
                padding: const EdgeInsets.all(0),
                height: 250,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Image.asset('images/kaguya-sama_Volume 22.jpg'),
                    ),
                  ],
                ),
              ),

              /// container ket. komik lainnya
              Container(
                padding: const EdgeInsets.only(left: 10.0, top: 25.0),
                alignment: Alignment.center,
                child: Text(
                  'Lihat Komik Lainnya',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                  ),
                ),
              ),

              /// container pilihan genre komik
              Container(
                padding: const EdgeInsets.only(left: 10, top: 20),
                height: 260,
                child: Column(
                  children: <Widget>[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: <Widget>[
                        /// text button Action
                        TextButton(
                          style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all(
                              Color.fromARGB(255, 218, 102, 67),
                            ),
                          ),
                          child: Text(
                            'Action',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                            ),
                          ),
                          onPressed: () {
                            Navigator.push(context,
                                MaterialPageRoute(builder: (context) {
                              return const ActionPage();
                            }));
                          },
                        ),

                        /// text button Misteri
                        TextButton(
                          style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all(
                              Color.fromARGB(255, 218, 102, 67),
                            ),
                          ),
                          child: Text(
                            'Misteri',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                            ),
                          ),
                          onPressed: () {},
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 20.0,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: <Widget>[
                        /// text button Komedi
                        TextButton(
                          style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all(
                              Color.fromARGB(255, 218, 102, 67),
                            ),
                          ),
                          child: Text(
                            'Komedi',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                            ),
                          ),
                          onPressed: () {},
                        ),

                        /// text button Romantis
                        TextButton(
                          style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all(
                              Color.fromARGB(255, 218, 102, 67),
                            ),
                          ),
                          child: Text(
                            'Romantis',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                            ),
                          ),
                          onPressed: () {},
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
