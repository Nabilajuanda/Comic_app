import 'package:comic_app/ui/bleach_detailed.dart';
import 'package:comic_app/ui/main_page.dart';
import 'package:flutter/material.dart';

class StartedPage extends StatelessWidget {
  const StartedPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 255, 121, 80),
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            /// Container Judul Halaman
            const Center(
              child: Text(
                'ComicPie',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 45,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 15),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  primary: Color.fromARGB(255, 218, 67, 67),
                ),
                child: const Text('Get Started'),
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) {
                    return const MainPage();
                  }));
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
